# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
generate_data.py
----------------
Generates a realistic synthetic car-price dataset, structured the same way
as the well-known Kaggle "Car Price Prediction" dataset (brand, model year,
mileage, engine specs, fuel/transmission type, etc.).

NOTE: Live internet access was not available in this environment, so a
synthetic dataset is generated here with realistic feature distributions
AND realistic underlying price relationships (newer cars / lower mileage /
bigger engines / premium brands -> higher price, plus random noise). This
keeps the rest of the pipeline (cleaning, EDA, modeling, evaluation)
exactly the same as it would be on a real downloaded CSV — simply swap in
your own car_data.csv with the same column names to use real data.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 2000

brands = ["Toyota", "Honda", "Ford", "BMW", "Audi", "Mercedes", "Hyundai",
          "Kia", "Volkswagen", "Nissan", "Tesla", "Chevrolet"]

# Brand "prestige" multiplier used only to generate realistic prices
brand_premium = {
    "Toyota": 1.00, "Honda": 1.00, "Ford": 0.95, "BMW": 1.55, "Audi": 1.50,
    "Mercedes": 1.60, "Hyundai": 0.85, "Kia": 0.85, "Volkswagen": 1.05,
    "Nissan": 0.95, "Tesla": 1.90, "Chevrolet": 0.95
}

fuel_types = ["Petrol", "Diesel", "Electric", "Hybrid"]
transmissions = ["Manual", "Automatic"]
owner_types = ["First", "Second", "Third"]

rows = []
current_year = 2026

for _ in range(N):
    brand = np.random.choice(brands)
    year = np.random.randint(2005, 2025)
    age = current_year - year

    fuel = np.random.choice(fuel_types, p=[0.45, 0.30, 0.10, 0.15])
    transmission = np.random.choice(transmissions, p=[0.4, 0.6])
    owner = np.random.choice(owner_types, p=[0.6, 0.3, 0.1])

    engine_size = round(np.random.uniform(1.0, 4.0), 1)   # litres
    horsepower = int(engine_size * np.random.uniform(55, 75) + np.random.normal(0, 8))
    horsepower = max(60, horsepower)

    # mileage tends to increase with age, with noise
    mileage = max(500, int(age * np.random.uniform(8000, 16000) + np.random.normal(0, 5000)))

    mpg = round(np.random.uniform(15, 45) - (engine_size * 2) + np.random.normal(0, 2), 1)
    mpg = max(8, mpg)
    if fuel == "Electric":
        mpg = None  # not applicable; will be handled in cleaning

    seats = np.random.choice([2, 4, 5, 7], p=[0.05, 0.15, 0.65, 0.15])

    accident_history = np.random.choice([0, 1], p=[0.75, 0.25])

    # --- realistic underlying price formula (ground truth signal + noise) ---
    base_price = 35000
    price = base_price * brand_premium[brand]
    price *= (1 - 0.045) ** age                     # depreciation with age
    price -= mileage * 0.05                          # mileage penalty
    price += (engine_size - 2.0) * 2500              # bigger engine -> pricier
    price += (horsepower - 150) * 30
    if fuel == "Electric":
        price += 4000
    elif fuel == "Hybrid":
        price += 2000
    elif fuel == "Diesel":
        price += 800
    if transmission == "Automatic":
        price += 1200
    if owner == "Second":
        price -= 1500
    elif owner == "Third":
        price -= 3000
    if accident_history == 1:
        price -= 2500
    price -= seats * 50  # negligible

    price += np.random.normal(0, 1800)  # random market noise
    price = max(800, round(price, 2))

    rows.append({
        "brand": brand,
        "year": year,
        "engine_size_l": engine_size,
        "horsepower": horsepower,
        "mileage_km": mileage,
        "mpg": mpg,
        "fuel_type": fuel,
        "transmission": transmission,
        "owner_type": owner,
        "seats": seats,
        "accident_history": accident_history,
        "price_usd": price
    })

df = pd.DataFrame(rows)

# Inject a few realistic data-quality issues for the cleaning step to handle
missing_idx = np.random.choice(df.index, size=40, replace=False)
df.loc[missing_idx, "mpg"] = np.nan

dup_rows = df.sample(15, random_state=1)
df = pd.concat([df, dup_rows], ignore_index=True)

outlier_idx = np.random.choice(df.index, size=5, replace=False)
df.loc[outlier_idx, "price_usd"] = df.loc[outlier_idx, "price_usd"] * 8  # extreme outliers

df.to_csv("/home/claude/car_price_prediction/data/car_data.csv", index=False)
print("Dataset generated:", df.shape)
print(df.head())
