# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
eda.py
------
Generates exploratory data analysis (EDA) visualizations for the cleaned
car price dataset and saves them as PNG files in outputs/figures/.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

RAW_PATH = "/home/claude/car_price_prediction/data/car_data.csv"
CLEAN_PATH = "/home/claude/car_price_prediction/data/car_data_clean.csv"
FIG_DIR = "/home/claude/car_price_prediction/outputs/figures"

sns.set_style("whitegrid")


def plot_price_distribution(raw_df):
    plt.figure(figsize=(8, 5))
    sns.histplot(raw_df["price_usd"], bins=40, kde=True, color="#4C72B0")
    plt.title("Distribution of Car Prices")
    plt.xlabel("Price (USD)")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/price_distribution.png", dpi=150)
    plt.close()


def plot_correlation_heatmap(clean_df):
    numeric_cols = ["engine_size_l", "horsepower", "mileage_km", "mpg",
                     "seats", "accident_history", "car_age", "price_usd"]
    corr = clean_df[numeric_cols].corr()

    plt.figure(figsize=(9, 7))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Correlation Heatmap (Numeric Features)")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/correlation_heatmap.png", dpi=150)
    plt.close()


def plot_price_vs_age(raw_df):
    plt.figure(figsize=(8, 5))
    sns.scatterplot(data=raw_df, x="year", y="price_usd", hue="fuel_type", alpha=0.6)
    plt.title("Car Price vs. Model Year (colored by fuel type)")
    plt.xlabel("Model Year")
    plt.ylabel("Price (USD)")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/price_vs_year.png", dpi=150)
    plt.close()


def plot_price_by_brand(raw_df):
    plt.figure(figsize=(10, 5))
    order = raw_df.groupby("brand")["price_usd"].median().sort_values(ascending=False).index
    sns.boxplot(data=raw_df, x="brand", y="price_usd", order=order, palette="viridis")
    plt.title("Price Distribution by Brand")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/price_by_brand.png", dpi=150)
    plt.close()


def plot_mileage_vs_price(raw_df):
    plt.figure(figsize=(8, 5))
    sns.scatterplot(data=raw_df, x="mileage_km", y="price_usd", alpha=0.5, color="#55A868")
    plt.title("Mileage vs. Price")
    plt.xlabel("Mileage (km)")
    plt.ylabel("Price (USD)")
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/mileage_vs_price.png", dpi=150)
    plt.close()


if __name__ == "__main__":
    raw_df = pd.read_csv(RAW_PATH)
    clean_df = pd.read_csv(CLEAN_PATH)

    plot_price_distribution(raw_df)
    plot_correlation_heatmap(clean_df)
    plot_price_vs_age(raw_df)
    plot_price_by_brand(raw_df)
    plot_mileage_vs_price(raw_df)

    print("EDA plots saved to", FIG_DIR)
