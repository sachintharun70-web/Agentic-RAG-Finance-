# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
preprocessing.py
-----------------
Loads the raw car dataset and performs data cleaning, feature engineering,
and feature selection. Saves the cleaned dataset for the modeling step.

Steps performed:
    1. Load raw data
    2. Remove duplicate rows
    3. Handle missing values (median/mode imputation)
    4. Remove extreme outliers in the target variable (IQR method)
    5. Feature engineering: derive 'car_age' from 'year'
    6. Encode categorical variables (one-hot encoding)
    7. Save cleaned dataset to disk
"""

import pandas as pd
import numpy as np

RAW_PATH = "/home/claude/car_price_prediction/data/car_data.csv"
CLEAN_PATH = "/home/claude/car_price_prediction/data/car_data_clean.csv"

CURRENT_YEAR = 2026


def load_data(path=RAW_PATH):
    df = pd.read_csv(path)
    return df


def clean_data(df):
    print(f"Initial shape: {df.shape}")

    # 1. Remove duplicate rows
    before = df.shape[0]
    df = df.drop_duplicates().reset_index(drop=True)
    print(f"Removed {before - df.shape[0]} duplicate rows")

    # 2. Handle missing values
    #    'mpg' is naturally missing for some rows (e.g. electric cars / data
    #    entry gaps) -> impute with the median of the column
    missing_before = df.isnull().sum().sum()
    df["mpg"] = df["mpg"].fillna(df["mpg"].median())
    print(f"Imputed {missing_before} missing values (median strategy for 'mpg')")

    # 3. Remove extreme outliers in price using the IQR method
    q1 = df["price_usd"].quantile(0.25)
    q3 = df["price_usd"].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    before = df.shape[0]
    df = df[(df["price_usd"] >= lower_bound) & (df["price_usd"] <= upper_bound)]
    print(f"Removed {before - df.shape[0]} outlier rows (IQR method on price_usd)")

    df = df.reset_index(drop=True)
    return df


def engineer_features(df):
    # Derived feature: car age is more directly useful to a model than year
    df["car_age"] = CURRENT_YEAR - df["year"]
    df = df.drop(columns=["year"])

    # One-hot encode categorical columns
    categorical_cols = ["brand", "fuel_type", "transmission", "owner_type"]
    df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

    return df


def select_features(df):
    # Feature selection: drop columns with near-zero correlation/variance
    # if needed. Here we keep all engineered features since the dataset is
    # already compact and each one carries a real predictive signal
    # (checked via the correlation heatmap in eda.py).
    target = "price_usd"
    feature_cols = [c for c in df.columns if c != target]
    return df[feature_cols + [target]]


if __name__ == "__main__":
    df = load_data()
    df = clean_data(df)
    df = engineer_features(df)
    df = select_features(df)

    df.to_csv(CLEAN_PATH, index=False)
    print(f"\nCleaned dataset saved to {CLEAN_PATH}")
    print(f"Final shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
