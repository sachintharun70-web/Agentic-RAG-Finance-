# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
train_model.py
---------------
Trains and evaluates multiple regression models for car price prediction:
    1. Linear Regression       (simple baseline)
    2. Random Forest Regressor (handles non-linearity well)
    3. Gradient Boosting Reg.  (typically strongest tabular performer)

For each model we report:
    - RMSE  (Root Mean Squared Error)
    - MAE   (Mean Absolute Error)
    - R2    (Coefficient of Determination)

The best-performing model (by R2 on the test set) is saved to disk along
with the fitted StandardScaler, and a feature-importance plot + an
actual-vs-predicted plot are generated.
"""

import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

CLEAN_PATH = "/home/claude/car_price_prediction/data/car_data_clean.csv"
FIG_DIR = "/home/claude/car_price_prediction/outputs/figures"
MODEL_DIR = "/home/claude/car_price_prediction/outputs/model"

sns.set_style("whitegrid")


def load_clean_data():
    df = pd.read_csv(CLEAN_PATH)
    X = df.drop(columns=["price_usd"])
    y = df["price_usd"]
    return X, y


def evaluate(name, y_true, y_pred):
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    print(f"{name:>20s}  |  RMSE: {rmse:9.2f}  |  MAE: {mae:9.2f}  |  R2: {r2:.4f}")
    return {"model": name, "rmse": rmse, "mae": mae, "r2": r2}


def main():
    X, y = load_clean_data()
    feature_names = X.columns.tolist()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Scale numeric features (important for Linear Regression)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    results = []

    # --- Model 1: Linear Regression ---
    lr = LinearRegression()
    lr.fit(X_train_scaled, y_train)
    pred_lr = lr.predict(X_test_scaled)
    results.append(evaluate("Linear Regression", y_test, pred_lr))

    # --- Model 2: Random Forest ---
    rf = RandomForestRegressor(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
    rf.fit(X_train, y_train)  # tree models don't need scaling
    pred_rf = rf.predict(X_test)
    results.append(evaluate("Random Forest", y_test, pred_rf))

    # --- Model 3: Gradient Boosting ---
    gb = GradientBoostingRegressor(
        n_estimators=300, learning_rate=0.05, max_depth=3, random_state=42
    )
    gb.fit(X_train, y_train)
    pred_gb = gb.predict(X_test)
    results.append(evaluate("Gradient Boosting", y_test, pred_gb))

    # --- Pick the best model by R2 ---
    results_df = pd.DataFrame(results).sort_values("r2", ascending=False)
    best_name = results_df.iloc[0]["model"]
    print(f"\nBest model: {best_name}")

    models = {"Linear Regression": (lr, pred_lr), "Random Forest": (rf, pred_rf),
              "Gradient Boosting": (gb, pred_gb)}
    best_model, best_pred = models[best_name]

    # Save results to JSON for the README / report
    with open(f"{MODEL_DIR}/metrics.json", "w") as f:
        json.dump(results, f, indent=2)

    # Save the best model + scaler
    joblib.dump(best_model, f"{MODEL_DIR}/best_model.joblib")
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.joblib")
    with open(f"{MODEL_DIR}/feature_names.json", "w") as f:
        json.dump(feature_names, f)

    # --- Plot: Actual vs Predicted (best model) ---
    plt.figure(figsize=(7, 7))
    plt.scatter(y_test, best_pred, alpha=0.5, color="#4C72B0")
    lims = [min(y_test.min(), best_pred.min()), max(y_test.max(), best_pred.max())]
    plt.plot(lims, lims, "r--", label="Perfect prediction")
    plt.xlabel("Actual Price (USD)")
    plt.ylabel("Predicted Price (USD)")
    plt.title(f"Actual vs. Predicted Price ({best_name})")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/actual_vs_predicted.png", dpi=150)
    plt.close()

    # --- Plot: Feature importance ---
    # Tree-based models expose feature_importances_; linear models expose
    # coefficients (on standardized features, so magnitude is comparable).
    if hasattr(best_model, "feature_importances_"):
        importances = pd.Series(best_model.feature_importances_, index=feature_names)
        importances = importances.sort_values(ascending=False).head(12)
        plt.figure(figsize=(8, 6))
        sns.barplot(x=importances.values, y=importances.index, color="#55A868")
        plt.title(f"Top Feature Importances ({best_name})")
        plt.xlabel("Importance")
        plt.tight_layout()
        plt.savefig(f"{FIG_DIR}/feature_importance.png", dpi=150)
        plt.close()
    elif hasattr(best_model, "coef_"):
        coefs = pd.Series(best_model.coef_, index=feature_names)
        coefs = coefs.reindex(coefs.abs().sort_values(ascending=False).index).head(12)
        colors = ["#55A868" if c > 0 else "#C44E52" for c in coefs.values]
        plt.figure(figsize=(8, 6))
        sns.barplot(x=coefs.values, y=coefs.index, palette=colors)
        plt.title(f"Top Standardized Coefficients ({best_name})")
        plt.xlabel("Coefficient (effect on price, standardized features)")
        plt.ylabel("Feature")
        plt.tight_layout()
        plt.savefig(f"{FIG_DIR}/feature_importance.png", dpi=150)
        plt.close()

    # --- Plot: Model comparison bar chart ---
    plt.figure(figsize=(8, 5))
    sns.barplot(data=results_df, x="model", y="r2", color="#4C72B0")
    plt.title("Model Comparison (R2 Score)")
    plt.ylabel("R2 Score")
    plt.ylim(0, 1)
    plt.tight_layout()
    plt.savefig(f"{FIG_DIR}/model_comparison_r2.png", dpi=150)
    plt.close()

    print("\nAll model artifacts and plots saved.")
    return results_df


if __name__ == "__main__":
    main()
