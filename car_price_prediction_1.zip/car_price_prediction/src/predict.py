# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
predict.py
----------
Demo script: loads the saved best model + scaler and predicts the price
for a single example car. Run this after train_model.py.

Usage:
    python3 predict.py
"""

import json
import joblib
import pandas as pd

MODEL_DIR = "/home/claude/car_price_prediction/outputs/model"


def build_input_row(feature_names, example: dict):
    """Builds a single-row DataFrame matching the training feature columns,
    filling any one-hot columns not present in `example` with 0."""
    row = {col: 0 for col in feature_names}
    row.update(example)
    return pd.DataFrame([row], columns=feature_names)


def main():
    model = joblib.load(f"{MODEL_DIR}/best_model.joblib")
    scaler = joblib.load(f"{MODEL_DIR}/scaler.joblib")
    with open(f"{MODEL_DIR}/feature_names.json") as f:
        feature_names = json.load(f)

    # Example: a 2021 Toyota, 1.8L petrol engine, automatic, first owner,
    # ~40,000 km mileage, no accidents.
    example = {
        "engine_size_l": 1.8,
        "horsepower": 140,
        "mileage_km": 40000,
        "mpg": 32.0,
        "seats": 5,
        "accident_history": 0,
        "car_age": 2026 - 2021,
        "brand_Toyota": 1,           # one-hot: brand
        "fuel_type_Petrol": 1,       # one-hot: fuel type
        "transmission_Manual": 0,    # 0 = Automatic (since Manual is the dummy column)
        "owner_type_Second": 0,
        "owner_type_Third": 0,
    }

    X_input = build_input_row(feature_names, example)

    # Linear Regression was trained on scaled features; tree models were not.
    # We detect this by checking if the model has a coef_ attribute.
    if hasattr(model, "coef_"):
        X_input_processed = scaler.transform(X_input)
    else:
        X_input_processed = X_input

    predicted_price = model.predict(X_input_processed)[0]
    print("Example input:")
    print(json.dumps(example, indent=2))
    print(f"\nPredicted price: ${predicted_price:,.2f}")


if __name__ == "__main__":
    main()
