# Team: Tharun, Sachin, Maheshwari, Jothibasu
"""
main.py
-------
Runs the full pipeline end-to-end, in order:
    1. generate_data.py   -> creates the raw dataset (skip if you have your own CSV)
    2. preprocessing.py   -> cleans data + feature engineering
    3. eda.py              -> saves exploratory visualizations
    4. train_model.py     -> trains/evaluates models, saves the best one
    5. predict.py          -> demonstrates a single prediction

Usage:
    python3 main.py
"""

import subprocess
import sys

STEPS = [
    "generate_data.py",
    "preprocessing.py",
    "eda.py",
    "train_model.py",
    "predict.py",
]


def run_step(script):
    print(f"\n{'=' * 60}\nRunning {script}\n{'=' * 60}")
    result = subprocess.run([sys.executable, script])
    if result.returncode != 0:
        print(f"Step {script} failed. Stopping pipeline.")
        sys.exit(1)


if __name__ == "__main__":
    for step in STEPS:
        run_step(step)
    print("\nPipeline completed successfully!")
