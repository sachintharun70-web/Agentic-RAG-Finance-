# Car Price Prediction — Machine Learning Project

**Team Members:** Tharun, Sachin, Maheshwari, Jothibasu

## 1. Introduction

This project builds a machine learning pipeline that predicts the resale
price of a used car from its specifications (brand, age, mileage, engine
size, fuel type, etc.). It covers the full ML workflow: data cleaning,
feature engineering, model training, evaluation, and visualization of
results.

Three regression models are trained and compared:
- **Linear Regression** (baseline)
- **Random Forest Regressor**
- **Gradient Boosting Regressor**

The best model (selected by R² on a held-out test set) is saved and can be
reused for predictions on new cars via `src/predict.py`.

## 2. Dataset

**Source:** A live internet connection was not available in the development
environment, so this project uses a **synthetically generated dataset**
(`src/generate_data.py`) that mirrors the structure of the well-known
Kaggle *"Car Price Prediction"* style datasets. It contains 2,000+ records
with the following columns:

| Column              | Description                                  |
|----------------------|-----------------------------------------------|
| `brand`              | Car manufacturer (12 brands)                  |
| `year`               | Model year                                    |
| `engine_size_l`      | Engine displacement (litres)                  |
| `horsepower`         | Engine power (hp)                             |
| `mileage_km`         | Total distance driven (km)                    |
| `mpg`                | Fuel efficiency (miles per gallon)             |
| `fuel_type`          | Petrol / Diesel / Electric / Hybrid            |
| `transmission`       | Manual / Automatic                             |
| `owner_type`         | First / Second / Third owner                  |
| `seats`              | Number of seats                                |
| `accident_history`   | 1 if the car has a prior accident, else 0      |
| `price_usd`          | **Target variable** — resale price in USD      |

The generator builds prices from a realistic underlying formula (brand
premium, depreciation by age, mileage penalty, engine/horsepower bonus,
fuel-type and transmission effects, accident penalty) plus random market
noise — then deliberately injects **duplicate rows, missing values, and
extreme outliers** so the cleaning step has real issues to solve, just like
a real-world scraped dataset would.

> **Using real data instead:** if you have an actual Kaggle CSV (e.g. the
> "Car Price Prediction" or "Vehicle Dataset" datasets), simply replace
> `data/car_data.csv` with your file using the **same column names**, skip
> `generate_data.py`, and the rest of the pipeline (cleaning → EDA →
> training → evaluation) runs unchanged.

### Preprocessing techniques applied (`src/preprocessing.py`)
1. **Duplicate removal** — exact duplicate rows dropped.
2. **Missing value imputation** — `mpg` missing values filled with the
   column median.
3. **Outlier removal** — extreme `price_usd` outliers removed using the
   IQR (interquartile range) method.
4. **Feature engineering** — `year` converted to `car_age` (more directly
   predictive and avoids the model treating year as an arbitrary large
   number).
5. **Categorical encoding** — `brand`, `fuel_type`, `transmission`,
   `owner_type` one-hot encoded.
6. **Feature scaling** — numeric features standardized (zero mean, unit
   variance) before training the Linear Regression model.

## 3. Machine Learning Models

| Model               | Why it was included                                          |
|---------------------|----------------------------------------------------------------|
| Linear Regression   | Simple, interpretable baseline; coefficients show direction/size of each feature's effect on price |
| Random Forest       | Captures non-linear relationships and feature interactions without much tuning |
| Gradient Boosting    | Sequential ensemble that often gives the strongest performance on tabular data |

All three were trained on an 80/20 train-test split (`random_state=42` for
reproducibility) and compared on the same held-out test set.

## 4. Project Structure

```
car_price_prediction/
├── data/
│   ├── car_data.csv            # raw (synthetic) dataset
│   └── car_data_clean.csv      # cleaned + feature-engineered dataset
├── src/
│   ├── generate_data.py        # creates the synthetic raw dataset
│   ├── preprocessing.py        # cleaning, feature engineering, selection
│   ├── eda.py                  # exploratory data analysis plots
│   ├── train_model.py          # trains/evaluates all 3 models, saves best
│   ├── predict.py              # demo: load saved model & predict a price
│   └── main.py                 # runs the full pipeline end-to-end
├── outputs/
│   ├── figures/                # all PNG charts (see Results section)
│   └── model/
│       ├── best_model.joblib
│       ├── scaler.joblib
│       ├── feature_names.json
│       └── metrics.json
├── requirements.txt
└── README.md
```

## 5. Setup & How to Run

```bash
# 1. (Recommended) create a virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the full pipeline (generates data, cleans it, trains models, evaluates, predicts)
cd src
python3 main.py
```

Or run each stage individually:

```bash
cd src
python3 generate_data.py     # creates data/car_data.csv
python3 preprocessing.py     # creates data/car_data_clean.csv
python3 eda.py                # creates outputs/figures/*.png (EDA)
python3 train_model.py       # trains models, saves best model + metrics
python3 predict.py            # demo prediction using the saved model
```

All generated figures are saved to `outputs/figures/`, and the trained
model artifacts to `outputs/model/`.

## 6. Results and Insights

### Model performance (test set)

| Model               | RMSE ($) | MAE ($)  | R² Score |
|----------------------|----------:|----------:|----------:|
| **Linear Regression**| **2,779.24** | **2,138.52** | **0.9507** |
| Gradient Boosting     | 3,193.06 | 2,321.06 | 0.9350 |
| Random Forest         | 4,441.02 | 3,259.04 | 0.8742 |

**Linear Regression performed best** on this dataset (R² ≈ 0.95), meaning
it explains about 95% of the variance in car prices on unseen data, with a
typical prediction error of roughly $2,100–2,800.

![Model comparison](outputs/figures/model_comparison_r2.png)

### Key findings from data analysis

- **Car age and mileage are the strongest negative predictors of price** —
  both show a strong negative correlation with price (~ -0.71 to -0.73),
  and the two are themselves highly correlated (older cars have higher
  mileage), confirming the classic depreciation pattern.
  ![Correlation heatmap](outputs/figures/correlation_heatmap.png)

- **Brand has a large effect on price** even after controlling for
  specs — premium brands (BMW, Audi, Mercedes, Tesla) command noticeably
  higher prices than mass-market brands (Hyundai, Kia, Chevrolet).
  ![Price by brand](outputs/figures/price_by_brand.png)

- **Engine size and horsepower correlate positively with price**, but are
  almost perfectly correlated with *each other* (0.96) — in a production
  setting one of the two could likely be dropped without losing much
  information.

- **The relationship between price and mileage/age is close to linear**
  once outliers are removed, which explains why plain Linear Regression
  out-performed the more flexible tree ensembles here — the underlying
  signal in this dataset doesn't have strong non-linear interactions for
  the trees to exploit, while the noise gives the higher-variance models
  (especially Random Forest) more chances to overfit.
  ![Mileage vs price](outputs/figures/mileage_vs_price.png)

- The standardized coefficients confirm the intuition: `car_age` and
  mass-market `brand_*` dummies push price down, while `horsepower` and
  `engine_size_l` push it up.
  ![Feature importance](outputs/figures/feature_importance.png)

### Actual vs. Predicted (best model)

![Actual vs predicted](outputs/figures/actual_vs_predicted.png)

Predictions cluster tightly around the perfect-prediction line, with a
slight loosening at the very low end of the price range (older, high-
mileage, low-value cars), which is consistent with the relatively higher
proportional noise applied to cheap cars in the underlying data.

## 7. Model Improvements & Future Enhancements

- **Hyperparameter tuning**: Random Forest and Gradient Boosting were run
  with reasonable defaults; a `GridSearchCV`/`RandomizedSearchCV` sweep
  over `max_depth`, `n_estimators`, and `learning_rate` would likely close
  some of the gap with Linear Regression, and could let the ensembles
  exceed it.
- **Cross-validation**: a single 80/20 split was used for clarity; k-fold
  cross-validation would give a more robust estimate of generalization
  performance and reduce sensitivity to the particular split.
- **Feature interactions**: explicitly engineering interaction terms
  (e.g. `engine_size × fuel_type`) or trying polynomial features for
  Linear Regression could capture non-linear effects more directly.
- **Regularization**: trying Ridge/Lasso regression could help if more
  correlated features (like `engine_size_l` and `horsepower`) are added,
  reducing multicollinearity issues.
- **Real-world data**: replacing the synthetic dataset with a real Kaggle
  dataset (or live market listings) would let the model capture pricing
  quirks that a hand-written generator formula cannot — e.g. regional
  demand effects, seasonal price swings, or brand-specific resale
  reputations.
- **Deployment**: wrapping `predict.py` in a small Flask/FastAPI service
  or Streamlit app would turn this into an interactive price-estimation
  tool.

## 9. Uploading to GitHub

This environment doesn't have the network access or your GitHub
credentials needed to create/push a repo directly, so run these commands
yourself from the unzipped project folder (any of the four team members
can do this — just swap in your own GitHub username/repo URL):

```bash
cd car_price_prediction
git init
git add .
git commit -m "Initial commit: car price prediction ML project"
git branch -M main
git remote add origin https://github.com/<your-username>/car-price-prediction.git
git push -u origin main
```

To add the rest of the team as collaborators, go to your new repo on
GitHub → **Settings → Collaborators → Add people**, and add the GitHub
usernames for **tharun**, **sachin**, **maheshwari**, and **jothibasu**.

If you'd rather skip GitHub, the ZIP file shared in this conversation is a
complete, ready-to-submit alternative.

## 10. Supporting Materials

All charts referenced above are available as standalone PNG files in
`outputs/figures/`:
- `price_distribution.png`
- `price_vs_year.png`
- `price_by_brand.png`
- `mileage_vs_price.png`
- `correlation_heatmap.png`
- `model_comparison_r2.png`
- `feature_importance.png`
- `actual_vs_predicted.png`
